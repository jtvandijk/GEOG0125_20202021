# Move all .xml files in to a different folder

mkdir xml
mv mix/*.xml xml/


# Rename the files replacing - with _

cd mix
rename -n 's/-/_/' *.pdb
rename 's/-/_/' *.pdb
rename -n 's/-(.*)$/-\U\1/' *.pdb

# Search and find files

grep --files-with-matches 'gas' xml/*
grep --files-with-matches 'liquid, metal' xml/*

# Pipelines

curl -s 'https://ocw.mit.edu/ans7870/6/6.006/s08/lecturenotes/files/t8.shakespeare.txt' \
  | tr '[:space:]' '[\n*]' \
  | sed 's/[^[:alpha:]]//g' \
  | tr '[:upper:]' '[:lower:]' \
  | grep -v '^$' \
  | sort \
  | uniq -c \
  | sort -n \
  | grep -E ' [a-z]{5,}$' \
  | tail -n 10

# Parallelising pipelines
PIPELINE='echo {} && curl -s {} \
  | tr "[:space:]" "[\n*]" \
  | sed "s/[^[:alpha:]]//g" \
  | tr "[:upper:]" "[:lower:]" \
  | grep -v "^$" \
  | sort \
  | uniq -c \
  | sort -n  \
  | grep -E " [a-z]{5,}$" \
  | tail -n 5'
cat books/top100 | parallel $PIPELINE

